# heltic_arduino_wifi_Device_Ghoster_LCD
using an Heltec Wifi 8 to continuously send disconnected Wifi device beacons to hide your devices from wifi sniffers
